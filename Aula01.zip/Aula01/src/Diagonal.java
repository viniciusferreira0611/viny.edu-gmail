
public interface Diagonal {
	double diagonal();
}
