
public class Poligonos extends Figuras {
private double base, altura;
	
	public Poligonos(double base, double altura)
	{
		this.base = base;
		this.altura = altura;
	}
	
	public double getBase()
	{
		return base;
	}
	public double getAltura()
	{
		return altura;
	}

	public double perimetro() {
		return 0;
	}

	public double area() {
		return 0;
	}
}
