
public abstract class Figuras3D {
	public abstract double volume();

}
